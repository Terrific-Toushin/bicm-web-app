<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AboutMenu extends Model
{
    protected $table = 'about_menu';
    protected $primaryKey = 'about_menu_id';
}
