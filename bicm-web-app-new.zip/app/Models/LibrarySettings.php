<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LibrarySettings extends Model
{
    protected $table = 'library_settings';
    protected $primaryKey = 'library_settings_id';
}
