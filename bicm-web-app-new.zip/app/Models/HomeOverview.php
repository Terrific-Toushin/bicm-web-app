<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeOverview extends Model
{
    protected $table = 'home_overview';
    protected $primaryKey = 'home_overview_id';
}
