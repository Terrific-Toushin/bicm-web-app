<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CourseSettings extends Model
{
    protected $table = 'course_settings';
    protected $primaryKey = 'course_settings_id';
}
