<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeWhy extends Model
{
    protected $table = 'home_why';
    protected $primaryKey = 'home_why_id';
}
