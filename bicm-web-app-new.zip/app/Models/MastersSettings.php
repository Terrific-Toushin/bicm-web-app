<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MastersSettings extends Model
{
    protected $table = 'masters_settings';
    protected $primaryKey = 'masters_setting_id';
}
