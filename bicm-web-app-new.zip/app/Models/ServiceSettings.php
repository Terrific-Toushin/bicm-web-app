<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServiceSettings extends Model
{
    protected $table = 'service_settings';
    protected $primaryKey = 'service_settings_id';
}
