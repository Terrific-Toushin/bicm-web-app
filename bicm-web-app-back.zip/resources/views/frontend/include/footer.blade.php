<!-- Footer Section Start -->
<div class="footer-section section bg-ivory">

    {{--<!-- Footer Top Section Start -->--}}
    {{--<div class="footer-top-section section py-5">--}}
        {{--<div class="container">--}}

            {{--<div class="row">--}}
                {{--<div class="col-md-7">--}}
                    {{--<div class="row">--}}
                        {{--<!-- Footer Widget Start -->--}}
                        {{--<div class="col-lg-3 col-md-6 col-12">--}}
                            {{--<div class="footer-widget">--}}

                                {{--<h4 class="widget-title">CONTACT INFO</h4>--}}

                                {{--<p class="contact-info">--}}
                                    {{--<span>Address</span>--}}
                                    {{--218, DR, KUDRATE KHODA ROAD <br>--}}
                                    {{--11 SAHERA TROPICAL CENTER(11th Floor)<br/>--}}
                                    {{--Dhaka-1205--}}
                                {{--</p>--}}

                                {{--<p class="contact-info">--}}
                                    {{--<span>Phone</span>--}}
                                    {{--<a href="tel:01234567890">+88 0173 883 4142</a>--}}
                                {{--</p>--}}

                                {{--<p class="contact-info">--}}
                                    {{--<span>Web</span>--}}
                                    {{--<a href="#">www.buyself.online</a>--}}
                                {{--</p>--}}

                            {{--</div>--}}
                        {{--</div><!-- Footer Widget End -->--}}

                        {{--<!-- Footer Widget Start -->--}}
                        {{--<div class="col-lg-3 col-md-6 col-12">--}}
                            {{--<div class="footer-widget">--}}

                                {{--<h4 class="widget-title">Help</h4>--}}

                                {{--<ul class="link-widget">--}}
                                    {{--<li><a href="#">Payment</a></li>--}}
                                    {{--<li><a href="#">Shipping</a></li>--}}
                                    {{--<li><a href="#">Cancellation & Returns</a></li>--}}
                                    {{--<li><a href="#">FAQ</a></li>--}}
                                    {{--<li><a href="#">Report Infringement</a></li>--}}
                                {{--</ul>--}}

                            {{--</div>--}}
                        {{--</div><!-- Footer Widget End -->--}}

                        {{--<!-- Footer Widget Start -->--}}
                        {{--<div class="col-lg-3 col-md-6 col-12">--}}
                            {{--<div class="footer-widget">--}}

                                {{--<h4 class="widget-title">POLICY</h4>--}}

                                {{--<ul class="link-widget">--}}
                                    {{--<li><a href="#">Return Policy</a></li>--}}
                                    {{--<li><a href="#">Terms Of Use</a></li>--}}
                                    {{--<li><a href="#">Security</a></li>--}}
                                    {{--<li><a href="#">Privacy</a></li>--}}
                                    {{--<li><a href="#">Sitemap</a></li>--}}
                                    {{--<li><a href="#">Gift coupon</a></li>--}}
                                    {{--<li><a href="#">Special coupon</a></li>--}}
                                {{--</ul>--}}

                            {{--</div>--}}
                        {{--</div><!-- Footer Widget End -->--}}

                        {{--<!-- Footer Widget Start -->--}}
                        {{--<div class="col-lg-3 col-md-6 col-12">--}}
                            {{--<div class="footer-widget">--}}

                                {{--<h4 class="widget-title">Social</h4>--}}

                                {{--<ul class="ee-social-contact">--}}
                                    {{--<a href="#" class="facebook-login">Find Us<i class="fa fa-facebook"></i></a>--}}
                                    {{--<a href="#" class="twitter-login">Find Us<i class="fa fa-twitter"></i></a>--}}
                                    {{--<a href="#" class="youtube-login">Find Us<i class="fa fa-youtube-play"></i></a>--}}
                                    {{--<a href="#" class="google-plus-login">Find Us<i class="fa fa-linkedin"></i></a>--}}
                                {{--</ul>--}}

                            {{--</div>--}}
                            {{--<div class="py-0 my-0" style="width: 0px;height: 120%;float: right;border: 1px inset;position: relative;top: -110px;"></div>--}}

                        {{--</div><!-- Footer Widget End -->--}}
                    {{--</div>--}}
                {{--</div>--}}
                {{--<div class="col-md-5">--}}
                    {{--<div class="row">--}}
                        {{--<!-- Footer Widget Start -->--}}
                        {{--<div class="col-md-6 col-12">--}}
                            {{--<div class="footer-widget">--}}

                                {{--<h4 class="widget-title">Mail Us</h4>--}}

                                {{--<div class="">--}}
                                    {{--<a href="#">info@buyself.online</a>--}}
                                    {{--Buy-Self Online Shopping,<br/>--}}
                                    {{--218, DR, KUDRATE KHODA ROAD <br>--}}
                                    {{--11 SAHERA TROPICAL CENTER(11th Floor)<br/>--}}
                                    {{--Dhaka-1205--}}
                                {{--</div>--}}

                            {{--</div>--}}
                        {{--</div><!-- Footer Widget End -->--}}
                        {{--<!-- Footer Widget Start -->--}}
                        {{--<div class="col-md-6 col-12">--}}
                            {{--<div class="footer-widget">--}}

                                {{--<h4 class="widget-title">Registered Office Address</h4>--}}

                                {{--<div class="">--}}
                                    {{--Greenpac Technologies Limited,<br/>--}}
                                    {{--Ground Floor, House:13,<br/>--}}
                                    {{--Road: 02, sector:06,<br/>--}}
                                    {{--Uttara,<br/>--}}
                                    {{--Dhaka - 1230<br/>--}}
                                    {{--Bangladesh<br/>--}}
                                    {{--Telephone: +88 0173 883 4142<br/>--}}
                                {{--</div>--}}

                            {{--</div>--}}
                        {{--</div><!-- Footer Widget End -->--}}
                    {{--</div>--}}
                {{--</div>--}}
            {{--</div>--}}

        {{--</div>--}}
    {{--</div><!-- Footer Bottom Section Start -->--}}

    <!-- Footer Bottom Section Start -->
    <div class="footer-bottom-section section">
        <div class="container">
            <div class="row">

                <!-- Footer Copyright -->
                <div class="col-lg-8 col-12">
                    <div class="row">
                        <div class="col">
                            <a><i class="fa fa-shopping-cart"></i> Sell On Greenpac</a>
                        </div>
                        <div class="col">
                            <a><i class="fa fa-star"></i> Advertise</a>
                        </div>
                        <div class="col">
                            <a><i class="fa fa-gift"></i> Gift Cards</a>
                        </div>
                        <div class="col">
                            <a><i class="fa fa-question-circle"></i> Help Center</a>
                        </div>
                        <div class="col">
                            <div class="footer-copyright">
                                <p>&copy; Copyright, <a href="#">E&E</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer Payment Support -->
                <div class="col-lg-4 col-12">
                    <div class="footer-payments-image"><img src="{{ asset('/') }}frontEnd/assets/images/payment-support.png" alt="Payment Support Image"></div>
                </div>

            </div>
        </div>
    </div><!-- Footer Bottom Section Start -->

</div><!-- Footer Section End -->