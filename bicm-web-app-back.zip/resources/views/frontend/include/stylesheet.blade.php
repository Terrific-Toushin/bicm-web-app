<!-- CSS
	============================================ -->

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{{ asset('/') }}frontEnd/assets/css/bootstrap.min.css">

<!-- Icon Font CSS -->
<link rel="stylesheet" href="{{ asset('/') }}frontEnd/assets/css/icon-font.min.css">

<!-- Plugins CSS -->
<link rel="stylesheet" href="{{ asset('/') }}frontEnd/assets/css/plugins.css">

<!-- Main Style CSS -->
<link rel="stylesheet" href="{{ asset('/') }}frontEnd/assets/css/style.css">

<!-- Modernizer JS -->
<script src="{{ asset('/') }}frontEnd/assets/js/vendor/modernizr-2.8.3.min.js"></script>

@yield('stylesheet')