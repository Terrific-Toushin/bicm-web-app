<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeService extends Model
{
    protected $table = 'home_service';
    protected $primaryKey = 'home_service_id';
}
