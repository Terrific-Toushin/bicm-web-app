<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResearchSettings extends Model
{
    protected $table = 'research_settings';
    protected $primaryKey = 'research_settings_id';
}
