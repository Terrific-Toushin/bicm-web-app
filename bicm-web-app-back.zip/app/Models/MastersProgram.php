<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MastersProgram extends Model
{
    protected $table = 'masters_program';
    protected $primaryKey = 'masters_program_id';
}
