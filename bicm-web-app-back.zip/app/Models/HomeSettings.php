<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeSettings extends Model
{
    protected $table = 'home_settings';
    protected $primaryKey = 'home_settings_id';
}
