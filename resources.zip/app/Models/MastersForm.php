<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MastersForm extends Model
{
    protected $table = 'masters_form';
    protected $primaryKey = 'masters_form_id';
}
