<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeProject extends Model
{
    protected $table = 'home_project';
    protected $primaryKey = 'home_project_id';
}
