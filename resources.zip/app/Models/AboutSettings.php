<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AboutSettings extends Model
{
    protected $table = 'about_settings';
    protected $primaryKey = 'about_settings_id';
}
