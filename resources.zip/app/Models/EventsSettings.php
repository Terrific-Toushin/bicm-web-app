<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EventsSettings extends Model
{
    protected $table = 'events_settings';
    protected $primaryKey = 'events_settings_id';
}
