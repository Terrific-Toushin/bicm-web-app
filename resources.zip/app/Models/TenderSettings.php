<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TenderSettings extends Model
{
    protected $table = 'tender_settings';
    protected $primaryKey = 'tender_settings_id';
}
