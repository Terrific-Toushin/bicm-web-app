<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Events;
use App\Models\FormData;
use App\Models\FormGroup;
use App\Models\FormGroupField;
use App\Models\HomeOverview;
use App\Models\HomeProject;
use App\Models\HomeService;
use App\Models\HomeSettings;
use App\Models\HomeWhy;
use App\Models\MastersProgram;
use App\Models\Menus;
use App\Models\Pages;
use Illuminate\Http\Request;

class FrontendController extends Controller
{
    public function index(){
        $header = HomeSettings::where('section_name','header')->where('status','Y')->first();
        $service = HomeSettings::where('section_name','service')->where('status','Y')->first();
        $overview = HomeSettings::where('section_name','overview')->where('status','Y')->first();
        $why = HomeSettings::where('section_name','why')->where('status','Y')->first();
        $project = HomeSettings::where('section_name','project')->where('status','Y')->first();
        $homeService = HomeService::orderBy('home_service_id','ASC')->get();
        $homeOverview = HomeOverview::orderBy('home_overview_id','ASC')->get();
        $homeWhy = HomeWhy::orderBy('home_why_id','ASC')->get();
        $homeProject = HomeProject::orderBy('home_project_id','ASC')->get();
        return view('frontend.home.home',[
            'header' => $header,
            'service' => $service,
            'overview' => $overview,
            'why' => $why,
            'project' => $project,
            'homeService' => $homeService,
            'homeOverview' => $homeOverview,
            'homeWhy' => $homeWhy,
            'homeProject' => $homeProject
        ]);
    }

    public function service(){
        return view('frontend.service.service');
    }

    public function pageDetails($url){
        $pageDetails = Pages::select('pages.*')->leftJoin('menus','menus.menu_id','=','pages.menu_id')->where('menus.url',$url)->where('pages.status','Y')->first();
        if(empty($pageDetails)){
            return view('frontend.notFound');
        }elseif($pageDetails->page_type == 'master'){
            $contentDetails = MastersProgram::where('page_id',$pageDetails->page_id)->where('status','Y')->get();
            $viewPage = 'frontend.pages.programDetails';
        }elseif ($pageDetails->page_type == 'courses'){
            $contentDetails = Course::where('page_id',$pageDetails->page_id)->where('status','Y')->get();
            $viewPage = 'frontend.pages.courseDetails';
        }elseif ($pageDetails->page_type == 'event'){
            $contentDetails = Events::where('page_id',$pageDetails->page_id)->where('status','Y')->get();
            $viewPage = 'frontend.pages.eventDetails';
        }else{
            if($pageDetails->form_status == 'Y'){
                $formList = FormGroup::select('ev_form_groups.name','ev_form_group_fields.*')->leftJoin('ev_form_group_fields','ev_form_group_fields.group_id','=','ev_form_groups.id')->whereIn('ev_form_groups.id',json_decode($pageDetails->form_group))->orderBy('ev_form_groups.id','ASC')->orderBy('ev_form_group_fields.forder','ASC')->get();
                $inputType = config("dashboard_constant.FIELD_TYPE");
                $contentDetails = [
                    'formList' => $formList,
                    'inputType' => $inputType
                ];
            }else{
                $contentDetails = [];
            }

            $viewPage = 'frontend.pages.pageDetails';
        }

        return view($viewPage,[
            'pageDetails' => $pageDetails,
            'contentDetails' => $contentDetails,
        ]);
    }

    public function programDetails($page_id){
        $pageDetails = MastersProgram::where('masters_program_id',$page_id)->where('status','Y')->first();
        return view('frontend.pages.masterProgram',[
            'pageDetails' => $pageDetails
        ]);
    }

    public function courseDetails($page_id){
        $pageDetails = Course::where('course_id',$page_id)->where('status','Y')->first();
        return view('frontend.pages.courseProgram',[
            'pageDetails' => $pageDetails
        ]);
    }

    public function eventDetails($page_id){
        $pageDetails = Events::where('events_id',$page_id)->where('status','Y')->first();
        return view('frontend.pages.eventProgram',[
            'pageDetails' => $pageDetails
        ]);
    }

    public function programForm($page_id,$program_id){
        $pageDetails = Pages::select('banner','heading','form_group','page_id','page_type')->where('page_id',$page_id)->where('status','Y')->first();
        $formList = FormGroup::select('ev_form_groups.name','ev_form_group_fields.*')->leftJoin('ev_form_group_fields','ev_form_group_fields.group_id','=','ev_form_groups.id')->whereIn('ev_form_groups.id',json_decode($pageDetails->form_group))->orderBy('ev_form_groups.id','ASC')->orderBy('ev_form_group_fields.forder','ASC')->get();
        $inputType = config("dashboard_constant.FIELD_TYPE");
        return view('frontend.pages.masterProgramForm',[
            'pageDetails' => $pageDetails,
            'formList' => $formList,
            'inputType' => $inputType,
            'program_id' => $program_id
        ]);
    }

    public function storeFormData(Request $request)
    {
        $formData = $request->except('_token');
        $aboutSettings = new FormData();
        $aboutSettings->form_id = floor(time() - 999999999);
        $aboutSettings->program_id = $request->program_id;
        $aboutSettings->page_id = $request->page_id;
        $aboutSettings->page_type = $request->page_type;
        $aboutSettings->form_data = json_encode($formData);
        if ($aboutSettings->save()) {
            return view('frontend.mastersProgram.payment');
        } else
            return redirect()->back()->with('failed', 'Form info Save Failed');
    }

    public function storeContactData(Request $request)
    {
        $formData = $request->except('_token');
        $aboutSettings = new FormData();
        $aboutSettings->form_id = floor(time() - 999999999);
        $aboutSettings->program_id = $request->program_id;
        $aboutSettings->page_id = $request->page_id;
        $aboutSettings->page_type = $request->page_type;
        $aboutSettings->form_data = json_encode($formData);
        if ($aboutSettings->save()) {
            return redirect()->route('home')->with('success', 'Side Bar info Save successfully');
        } else
            return redirect()->back()->with('failed', 'Form info Save Failed');
    }

    public function mastersProgram(){
        return view('frontend.mastersProgram.mastersProgram');
    }

    public function certificationTraining(){
        return view('frontend.certificationTraining.certificationTraining');
    }

    public function approch(){
        return view('frontend.approch.approch');
    }

    public function diploma(){
        return view('frontend.diploma.diploma');
    }
}
