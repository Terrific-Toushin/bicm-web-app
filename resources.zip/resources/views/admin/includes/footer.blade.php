
<footer>
    <div class="pull-right">
        &copy; Copyright Reserved by <a href="#">GreenPac</a>
    </div>
    <div class="clearfix"></div>
</footer>